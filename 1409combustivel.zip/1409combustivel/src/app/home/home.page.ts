import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  
  combustiveis=[
    'inicio.jpeg',
    'etanol.jpg',
    'gasolina.jpg',
    'tantofaz.jpg'

  ];
    imagem = this.combustiveis[0];
    gasolina = null;
    etanol = null;

  constructor() {}
  

verificar(): void{
const resp =this.etanol / this.gasolina;

if(resp < 0.7){
  this.imagem = this.combustiveis[1];
}else if(resp > 0.7){
  this.imagem = this.combustiveis[2];
}
else{
  this.imagem = this.combustiveis[3];
}

}
    
 }


